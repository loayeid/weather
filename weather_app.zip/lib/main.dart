import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Weather App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const WeatherScreen(),
    );
  }
}

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key});

  @override
  WeatherScreenState createState() => WeatherScreenState();
}

class WeatherScreenState extends State<WeatherScreen> {
  String city = "Beirut";
  String temperature = "Loading...";
  String description = "";
  List<Map<String, String>> forecast = [];

  Future<void> fetchWeather() async {
    const url =
        "https://api.open-meteo.com/v1/forecast?latitude=33.8938&longitude=35.50188&hourly=temperature_2m&daily=temperature_2m_max,temperature_2m_min&timezone=auto";

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          temperature = "${data['hourly']['temperature_2m'][0]}°C";
          description = "Clear Sky";
          forecast = [
            {"day": "Mon", "temp": "25°C", "icon": "sun"},
            {"day": "Tue", "temp": "22°C", "icon": "cloud"},
            {"day": "Wed", "temp": "20°C", "icon": "rain"},
            {"day": "Thu", "temp": "18°C", "icon": "cloud-sun"},
            {"day": "Fri", "temp": "21°C", "icon": "wind"},
          ];
        });
      } else {
        setState(() {
          temperature = "Error!";
          description = "Could not fetch weather.";
        });
      }
    } catch (e) {
      setState(() {
        temperature = "Error!";
        description = "Could not fetch weather.";
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchWeather();
  }

  IconData getWeatherIcon(String condition) {
    switch (condition) {
      case "sun":
        return FontAwesomeIcons.sun;
      case "cloud":
        return FontAwesomeIcons.cloud;
      case "rain":
        return FontAwesomeIcons.cloudRain;
      case "cloud-sun":
        return FontAwesomeIcons.cloudSun;
      case "wind":
        return FontAwesomeIcons.wind;
      default:
        return FontAwesomeIcons.questionCircle;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather App'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              children: [
                const Icon(
                  FontAwesomeIcons.cloudSun,
                  size: 80,
                  color: Colors.blue,
                ),
                const SizedBox(height: 20),
                Text(
                  'City: $city',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Temperature: $temperature',
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blueAccent,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 20,
                    fontStyle: FontStyle.italic,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "5-Day Forecast:",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: forecast.map((day) {
                    return Column(
                      children: [
                        Icon(
                          getWeatherIcon(day['icon']!),
                          size: 40,
                          color: Colors.blueAccent,
                        ),
                        const SizedBox(height: 5),
                        Text(
                          day['day']!,
                          style: const TextStyle(fontSize: 16),
                        ),
                        Text(
                          day['temp']!,
                          style: const TextStyle(fontSize: 16),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ],
            ),
            ElevatedButton.icon(
              onPressed: fetchWeather,
              icon: const Icon(FontAwesomeIcons.rotateRight),
              label: const Text('Refresh'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                textStyle: const TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
